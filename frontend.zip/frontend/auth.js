// Redirect to login if not authenticated
function requireAuth() {
    const token = localStorage.getItem("authToken");
    if (!token) {
        window.location.href = "login.html";
    }
    return token;
}

// Logout function
function logout() {
    localStorage.removeItem("authToken");
    window.location.href = "login.html";
}

// Login logic 
async function login() {
    const deviceId = document.getElementById("deviceId").value;
    const password = document.getElementById("password").value;

    const res = await fetch("http://localhost:8080/api/login", {  
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deviceId, password })
    });

    if (!res.ok) {
        document.getElementById("error").textContent = "Invalid login!";
        return;
    }

    const data = await res.json();
    localStorage.setItem("authToken", data.token);

    window.location.href = "index.html";
}
