const token = requireAuth();   // ensures login before loading page

async function fetchJSON(url) {
    try {
        const res = await fetch(url, {
            headers: { "Authorization": "Bearer " + token }
        });
        if (res.status === 401) {
            logout();
            return;
        }
        return res.json();
    } catch (err) {
        console.error("Fetch error:", err);
        return null;
    }
}

function renderChart(canvasId, labels, data) {
    new Chart(document.getElementById(canvasId), {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: "Mood Average",
                data,
                borderWidth: 2,
                tension: 0.3
            }]
        },
        options: {
            scales: {
                y: { min: 1, max: 3, ticks: { stepSize: 1 } }
            }
        }
    });
}

function moodLabel(avg) {
    if (avg === null || avg === undefined) return "No entries today";

    const rounded = Math.round(avg);
    if (rounded === 1) return "Bad";
    if (rounded === 2) return "Ok";
    if (rounded === 3) return "Good";
    return "No entries today";
}

async function loadToday() {
    const today = await fetchJSON("http://localhost:8080/api/mood/today");

    // handle fetch failure or missing avg
    if (!today || today.avg === null || today.avg === undefined) {
        document.getElementById("today-value").textContent = "No entries today";
        return;
    }

    document.getElementById("today-value").textContent = moodLabel(today.avg);
}


async function loadCharts() {
    const last7 = await fetchJSON("http://localhost:8080/api/mood/7days");   
    const last30 = await fetchJSON("http://localhost:8080/api/mood/30days"); 

    // 7-day chart
    const chart7 = document.getElementById("chart7");
    if (!last7 || last7.length === 0) {
        const noDataDiv = document.createElement("div");
        noDataDiv.textContent = "No entries for last 7 days";
        noDataDiv.style.fontSize = "1.5rem";      // same as #today-value
        noDataDiv.style.textAlign = "left";       // left-aligned
        noDataDiv.style.margin = "10px 0";        // optional spacing
        chart7.replaceWith(noDataDiv);
    } else {
        renderChart("chart7", last7.map(e => e.date), last7.map(e => e.avg));
    }

    // 30-day chart
    const chart30 = document.getElementById("chart30");
    if (!last30 || last30.length === 0) {
        const noDataDiv = document.createElement("div");
        noDataDiv.textContent = "No entries for last 30 days";
        noDataDiv.style.fontSize = "1.5rem";      // same as #today-value
        noDataDiv.style.textAlign = "left";       // left-aligned
        noDataDiv.style.margin = "10px 0";
        chart30.replaceWith(noDataDiv);
    } else {
        renderChart("chart30", last30.map(e => e.date), last30.map(e => e.avg));
    }
}

async function loadReminders() {
    const data = await fetchJSON("http://localhost:8080/api/reminders");
    if (!data) return;

    document.getElementById("reminder1").value = data.reminder1 || "";
    document.getElementById("reminder1-enabled").checked = !!data.reminder1;

    document.getElementById("reminder2").value = data.reminder2 || "";
    document.getElementById("reminder2-enabled").checked = !!data.reminder2;

    document.getElementById("reminder3").value = data.reminder3 || "";
    document.getElementById("reminder3-enabled").checked = !!data.reminder3;
}



loadToday();
loadCharts();
loadReminders();

document.getElementById("reminder-form").addEventListener("submit", async (e) => {
    e.preventDefault();

    const r1 = document.getElementById("reminder1-enabled").checked ? document.getElementById("reminder1").value : null;
    const r2 = document.getElementById("reminder2-enabled").checked ? document.getElementById("reminder2").value : null;
    const r3 = document.getElementById("reminder3-enabled").checked ? document.getElementById("reminder3").value : null;

    const res = await fetch("http://localhost:8080/api/reminders", {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + token
        },
        body: JSON.stringify({ reminder1: r1, reminder2: r2, reminder3: r3 })
    });

    const statusEl = document.getElementById("reminder-status");
    if (res.ok) {
        statusEl.textContent = "Reminders updated!";
        statusEl.style.color = "green";
    } else {
        statusEl.textContent = "Failed to update reminders.";
        statusEl.style.color = "red";
    }

    setTimeout(() => { statusEl.textContent = ""; }, 3000);
});



