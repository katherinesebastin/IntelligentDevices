const token = requireAuth();   // ensures login before loading page

async function fetchJSON(url) {
    const res = await fetch(url, {
        headers: {
            "Authorization": "Bearer " + token
        }
    });

    if (res.status === 401) {   // token expired or invalid
        logout();
        return;
    }
    return res.json();
}

function renderChart(canvasId, labels, data) {
    new Chart(document.getElementById(canvasId), {
        type: 'line',
        data: {
            labels,
            datasets: [{
                label: "Mood Average",
                data,
                borderWidth: 2,
                tension: 0.3
            }]
        },
        options: {
            scales: {
                y: { min: 1, max: 3, ticks: { stepSize: 1 } }
            }
        }
    });
}

async function loadToday() {
    const today = await fetchJSON("http://localhost:8080/api/mood/today");   
    document.getElementById("today-value").textContent = today.avg.toFixed(2);
}

async function loadCharts() {
    const last7 = await fetchJSON("http://localhost:8080/api/mood/7days");   
    const last30 = await fetchJSON("http://localhost:8080/api/mood/30days"); 

    renderChart("chart7", last7.map(e => e.date), last7.map(e => e.avg));
    renderChart("chart30", last30.map(e => e.date), last30.map(e => e.avg));
}

loadToday();
loadCharts();
