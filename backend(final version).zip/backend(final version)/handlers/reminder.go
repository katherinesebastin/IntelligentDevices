package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"backend/db"
	"backend/middleware"
)

// validateAndParseTime checks if input is a valid "HH:MM:SS" time string.
// Returns (*time.Time, nil) if valid,
// returns (nil, nil) if input is nil (means clear reminder),
// returns error if invalid.
func validateAndParseTime(input *string) (*time.Time, error) {
	if input == nil {
		return nil, nil
	}

	if *input == "" {
		return nil, nil // treat empty string as clearing the reminder
	}

	// If string has only HH:MM, append ":00"
	tStr := *input
	if len(tStr) == 5 { // "HH:MM"
		tStr += ":00"
	}

	layout := "15:04:05"
	t, err := time.Parse(layout, tStr)
	if err != nil {
		return nil, fmt.Errorf("invalid time format, expected HH:MM or HH:MM:SS")
	}

	return &t, nil
}

// GetReminders returns the reminder times for the authenticated device
func GetReminders(w http.ResponseWriter, r *http.Request) {
	deviceID := r.Context().Value(middleware.DeviceIDKey).(int)

	var reminder1, reminder2, reminder3 *time.Time
	err := db.DB.QueryRow(
		`SELECT reminder1, reminder2, reminder3 FROM devices WHERE id = $1`,
		deviceID,
	).Scan(&reminder1, &reminder2, &reminder3)

	if err != nil {
		http.Error(w, "Error fetching reminders", http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"reminder1": formatTime(reminder1),
		"reminder2": formatTime(reminder2),
		"reminder3": formatTime(reminder3),
	})
}

func UpdateReminders(w http.ResponseWriter, r *http.Request) {
	deviceID := r.Context().Value(middleware.DeviceIDKey).(int)

	var input struct {
		Reminder1 *string `json:"reminder1"`
		Reminder2 *string `json:"reminder2"`
		Reminder3 *string `json:"reminder3"`
	}

	if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	// Validate each reminder time
	r1, err := validateAndParseTime(input.Reminder1)
	if err != nil {
		http.Error(w, "reminder1: "+err.Error(), http.StatusBadRequest)
		return
	}

	r2, err := validateAndParseTime(input.Reminder2)
	if err != nil {
		http.Error(w, "reminder2: "+err.Error(), http.StatusBadRequest)
		return
	}

	r3, err := validateAndParseTime(input.Reminder3)
	if err != nil {
		http.Error(w, "reminder3: "+err.Error(), http.StatusBadRequest)
		return
	}

	// Apply update
	_, err = db.DB.Exec(
		`UPDATE devices 
		 SET reminder1 = $1, reminder2 = $2, reminder3 = $3 
		 WHERE id = $4`,
		r1, r2, r3, deviceID,
	)
	if err != nil {
		http.Error(w, "Error updating reminders", http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusNoContent)
}

// Helper to format *time.Time to "HH:MM:SS" string
func formatTime(t *time.Time) *string {
	if t == nil {
		return nil
	}
	s := t.Format("15:04:05")
	return &s
}
