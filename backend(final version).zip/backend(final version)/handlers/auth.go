package handlers

import (
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"strings"
	"time"

	"backend/db"

	"github.com/golang-jwt/jwt/v5"
)

var jwtSecret = []byte(os.Getenv("JWT_SECRET"))

func LoginHandler(w http.ResponseWriter, r *http.Request) {
	var input struct {
		DeviceID string `json:"deviceId"`
		Password string `json:"password"`
	}

	// Decode JSON and check for errors
	if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	// Normalize input
	input.DeviceID = strings.TrimSpace(strings.ToLower(input.DeviceID))
	input.Password = strings.TrimSpace(input.Password)

	var dbPassword string
	var numericDeviceID int

	// Fetch numeric device ID and password from database
	err := db.DB.QueryRow(
		"SELECT id, password FROM devices WHERE device_id = $1",
		input.DeviceID,
	).Scan(&numericDeviceID, &dbPassword)

	if err != nil {
		fmt.Println("DB query error:", err)
		http.Error(w, "Invalid login", http.StatusUnauthorized)
		return
	}

	dbPassword = strings.TrimSpace(dbPassword)

	if input.Password != dbPassword {
		fmt.Println("Password mismatch")
		http.Error(w, "Invalid login", http.StatusUnauthorized)
		return
	}

	// Build JWT token with numeric device ID
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"deviceid": numericDeviceID,
		"exp":      time.Now().Add(24 * time.Hour).Unix(),
	})

	tokenString, err := token.SignedString(jwtSecret)
	if err != nil {
		http.Error(w, "Error generating token", http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(map[string]string{
		"token": tokenString,
	})
}
