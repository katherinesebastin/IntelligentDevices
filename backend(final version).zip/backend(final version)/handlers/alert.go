package handlers

import (
	"backend/service"
	"encoding/json"
	"net/http"
)

type AlertHandler struct {
	AlertService *service.AlertService
}

func NewAlertHandler(s *service.AlertService) *AlertHandler {
	return &AlertHandler{AlertService: s}
}

func (h *AlertHandler) GetAlerts(w http.ResponseWriter, r *http.Request) {

	result, err := h.AlertService.CheckForAlert(1)
	if err != nil {
		http.Error(w, "Failed to fetch alerts", 500)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(result)
}
