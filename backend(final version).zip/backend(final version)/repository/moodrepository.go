package repository

import (
	"context"
	"database/sql"
	"fmt"
)

type MoodRepository struct {
	DB *sql.DB
}

func NewMoodRepository(db *sql.DB) *MoodRepository {
	return &MoodRepository{DB: db}
}

func (r *MoodRepository) InsertMood(ctx context.Context, mood int, deviceID int) error {
    fmt.Println("Inserting mood:", mood, "for deviceID:", deviceID)
    _, err := r.DB.ExecContext(ctx,
        `INSERT INTO prototypedevice (entry_date, mood, device_id)
         VALUES (CURRENT_DATE, $1, $2)`,
        mood, deviceID,
    )
    if err != nil {
        fmt.Println("DB ERROR:", err)
    }
    return err
}

