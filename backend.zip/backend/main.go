package main

import (
	"fmt"
	"log"
	"net/http"

	"backend/db"
	"backend/handlers"
	"backend/middleware"
	"backend/repository"
	"backend/service"

	"github.com/gorilla/mux"
	"github.com/joho/godotenv"
	"github.com/rs/cors"
)

func main() {
	if err := godotenv.Load(); err != nil {
		fmt.Println("Warning: .env file not found, relying on system environment variables")
	}

	db.Connect() // Make sure this returns *sql.DB or pgxpool.Pool

	r := mux.NewRouter()

	// ---------------- Public Routes ----------------
	r.HandleFunc("/api/login", handlers.LoginHandler).Methods("POST")

	// ---------------- Arduino Handler ----------------
moodRepo := repository.NewMoodRepository(db.DB)
moodService := service.NewMoodService(moodRepo)
arduinoHandler := handlers.NewArduinoHandler(moodService)
r.HandleFunc("/addMood", arduinoHandler.HandleMood).Methods("POST")

	// ---------------- Protected Routes ----------------
	api := r.PathPrefix("/api").Subrouter()
	api.Use(middleware.AuthMiddleware)

	api.HandleFunc("/mood/today", handlers.TodayHandler).Methods("GET")
	api.HandleFunc("/mood/7days", handlers.SevenDaysHandler).Methods("GET")
	api.HandleFunc("/mood/30days", handlers.ThirtyDaysHandler).Methods("GET")
	api.HandleFunc("/reminders", handlers.GetReminders).Methods("GET")
	api.HandleFunc("/reminders", handlers.UpdateReminders).Methods("PUT")

	handler := cors.AllowAll().Handler(r)

	fmt.Println("Backend running at http://localhost:8080")
	log.Fatal(http.ListenAndServe("0.0.0.0:8080", handler))
}
