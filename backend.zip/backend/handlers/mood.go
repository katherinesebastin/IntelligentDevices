package handlers

import (
	"encoding/json"
	"net/http"
	"time"

	"backend/db"
	"backend/middleware"
)

// TodayHandler returns the average mood for today for the authenticated device
func TodayHandler(w http.ResponseWriter, r *http.Request) {
	deviceID := r.Context().Value(middleware.DeviceIDKey).(int)

	today := time.Now().Format("2006-01-02")

	var avg float64
	err := db.DB.QueryRow(
		`SELECT AVG(mood) 
		 FROM prototypedevice 
		 WHERE entry_date = $1 AND device_id = $2`,
		today, deviceID,
	).Scan(&avg)

	if err != nil {
		http.Error(w, "Error fetching data", http.StatusInternalServerError)
		return
	}

	json.NewEncoder(w).Encode(map[string]float64{"avg": avg})
}

// SevenDaysHandler returns the average mood for the last 7 days for the authenticated device
func SevenDaysHandler(w http.ResponseWriter, r *http.Request) {
	deviceID := r.Context().Value(middleware.DeviceIDKey).(int)

	today := time.Now()
	start := today.AddDate(0, 0, -6)

	rows, err := db.DB.Query(
		`SELECT entry_date, AVG(mood)
		 FROM prototypedevice
		 WHERE entry_date BETWEEN $1 AND $2 AND device_id = $3
		 GROUP BY entry_date
		 ORDER BY entry_date ASC`,
		start.Format("2006-01-02"), today.Format("2006-01-02"), deviceID,
	)
	if err != nil {
		http.Error(w, "Error fetching data", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var days []map[string]interface{}
	for rows.Next() {
		var date time.Time
		var avg float64

		if err := rows.Scan(&date, &avg); err != nil {
			http.Error(w, "Error scanning data", http.StatusInternalServerError)
			return
		}

		days = append(days, map[string]interface{}{
			"date": date.Format("2006-01-02"),
			"avg":  avg,
		})
	}

	json.NewEncoder(w).Encode(days)
}

// ThirtyDaysHandler returns the average mood for the last 30 days for the authenticated device
func ThirtyDaysHandler(w http.ResponseWriter, r *http.Request) {
	deviceID := r.Context().Value(middleware.DeviceIDKey).(int)

	today := time.Now()
	start := today.AddDate(0, 0, -29)

	rows, err := db.DB.Query(
		`SELECT entry_date, AVG(mood)
		 FROM prototypedevice
		 WHERE entry_date BETWEEN $1 AND $2 AND device_id = $3
		 GROUP BY entry_date
		 ORDER BY entry_date ASC`,
		start.Format("2006-01-02"), today.Format("2006-01-02"), deviceID,
	)
	if err != nil {
		http.Error(w, "Error fetching data", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	var days []map[string]interface{}
	for rows.Next() {
		var date time.Time
		var avg float64

		if err := rows.Scan(&date, &avg); err != nil {
			http.Error(w, "Error scanning data", http.StatusInternalServerError)
			return
		}

		days = append(days, map[string]interface{}{
			"date": date.Format("2006-01-02"),
			"avg":  avg,
		})
	}

	json.NewEncoder(w).Encode(days)
}
