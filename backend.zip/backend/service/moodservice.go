package service

import (
	"context"
	"backend/repository"
)

type MoodService struct {
	Repo *repository.MoodRepository
}

func NewMoodService(repo *repository.MoodRepository) *MoodService {
	return &MoodService{Repo: repo}
}

// SaveMood saves a mood for a given device ID
func (s *MoodService) SaveMood(ctx context.Context, mood int, deviceID int) error {
	return s.Repo.InsertMood(ctx, mood, deviceID)
}
